export interface Instructor {
  id: number;
  name: string;
  title: string;
  avatar: string;
  bio: string;
}

export interface Course {
  id: number;
  title: string;
  description: string;
  thumbnail: string;
  price: number;
  rating: number;
  duration: string;
  students: number;
  category: string;
  featured: boolean;
  instructor: Instructor;
  lessons: number;
  level: 'Débutant' | 'Intermédiaire' | 'Avancé';
}