import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { FacebookProvider } from 'react-facebook';
import App from './App.tsx';
import './index.css';

document.title = 'Virus Mentale | Formation en ligne';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <GoogleOAuthProvider clientId="YOUR_GOOGLE_CLIENT_ID">
      <FacebookProvider appId="YOUR_FACEBOOK_APP_ID">
        <App />
      </FacebookProvider>
    </GoogleOAuthProvider>
  </StrictMode>
);