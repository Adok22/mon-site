import { Course, Instructor } from '../types/course';

export const mockInstructors: Instructor[] = [
  {
    id: 1,
    name: 'Alexandre Martin',
    title: 'Expert en Développement Web',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Alexandre est développeur web depuis plus de 10 ans, spécialisé dans les technologies JavaScript modernes. Il a travaillé pour plusieurs grandes entreprises technologiques avant de se consacrer à l\'enseignement.'
  },
  {
    id: 2,
    name: 'Sophie Bernard',
    title: 'Consultante en Marketing Digital',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Sophie a plus de 8 ans d\'expérience en marketing digital. Elle a aidé de nombreuses entreprises à développer leur présence en ligne et à optimiser leurs campagnes publicitaires.'
  },
  {
    id: 3,
    name: 'Marc Dupont',
    title: 'Designer UX/UI Senior',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Marc est un designer passionné avec une expertise en UX/UI. Il a travaillé sur des projets pour des startups et des entreprises Fortune 500, créant des expériences utilisateur exceptionnelles.'
  },
  {
    id: 4,
    name: 'Julie Moreau',
    title: 'Experte en Data Science',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Julie est titulaire d\'un doctorat en mathématiques appliquées et possède une vaste expérience en data science et intelligence artificielle. Elle a publié plusieurs articles académiques sur le sujet.'
  }
];

export const mockCourses: Course[] = [
  {
    id: 1,
    title: 'Développement Web Fullstack avec React et Node.js',
    description: 'Apprenez à créer des applications web complètes en utilisant React pour le frontend et Node.js pour le backend. Ce cours couvre toutes les étapes, du développement à la mise en production.',
    thumbnail: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 149.99,
    rating: 4.8,
    duration: '42h',
    students: 1547,
    category: 'Développement Web',
    featured: true,
    instructor: mockInstructors[0],
    lessons: 75,
    level: 'Intermédiaire'
  },
  {
    id: 2,
    title: 'Marketing Digital: Stratégies Avancées',
    description: 'Maîtrisez les stratégies de marketing digital les plus efficaces. Vous apprendrez à optimiser vos campagnes publicitaires, à analyser les données et à maximiser votre ROI.',
    thumbnail: 'https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 129.99,
    rating: 4.6,
    duration: '36h',
    students: 982,
    category: 'Marketing Digital',
    featured: true,
    instructor: mockInstructors[1],
    lessons: 54,
    level: 'Avancé'
  },
  {
    id: 3,
    title: 'Design UX/UI: Principes et Pratiques',
    description: 'Découvrez comment créer des interfaces utilisateur intuitives et esthétiques. Ce cours vous guidera à travers les principes du design UX/UI et vous montrera comment les appliquer à vos projets.',
    thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 99.99,
    rating: 4.7,
    duration: '28h',
    students: 765,
    category: 'Design UX/UI',
    featured: true,
    instructor: mockInstructors[2],
    lessons: 48,
    level: 'Débutant'
  },
  {
    id: 4,
    title: 'Introduction à la Data Science avec Python',
    description: 'Plongez dans le monde de la data science avec Python. Vous apprendrez les fondamentaux de l\'analyse de données, la visualisation et l\'introduction au machine learning.',
    thumbnail: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 119.99,
    rating: 4.9,
    duration: '38h',
    students: 1243,
    category: 'Data Science',
    featured: false,
    instructor: mockInstructors[3],
    lessons: 62,
    level: 'Intermédiaire'
  },
  {
    id: 5,
    title: 'Entrepreneuriat: Lancer et Développer sa Startup',
    description: 'Apprenez à transformer votre idée en entreprise prospère. Ce cours couvre toutes les étapes de la création d\'une startup, du business plan à la levée de fonds.',
    thumbnail: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 159.99,
    rating: 4.5,
    duration: '45h',
    students: 876,
    category: 'Business',
    featured: false,
    instructor: mockInstructors[1],
    lessons: 68,
    level: 'Débutant'
  },
  {
    id: 6,
    title: 'Développement Personnel et Leadership',
    description: 'Développez vos compétences en leadership et en communication. Ce cours vous aidera à améliorer votre confiance en vous et à devenir un leader plus efficace.',
    thumbnail: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 89.99,
    rating: 4.7,
    duration: '24h',
    students: 1892,
    category: 'Développement Personnel',
    featured: true,
    instructor: mockInstructors[3],
    lessons: 36,
    level: 'Débutant'
  }
];