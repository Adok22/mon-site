import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Clock, Book, BarChart, Award, User, Check, Video, ChevronDown, ChevronUp, ShoppingCart, Heart } from 'lucide-react';
import { Course } from '../types/course';
import { mockCourses } from '../data/mockData';

interface LessonSection {
  id: number;
  title: string;
  duration: string;
  lessons: {
    id: number;
    title: string;
    duration: string;
    isFree: boolean;
  }[];
}

const CourseDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [openSections, setOpenSections] = useState<number[]>([1]);
  
  // Mock lesson sections data
  const lessonSections: LessonSection[] = [
    {
      id: 1,
      title: 'Introduction',
      duration: '1h 30m',
      lessons: [
        { id: 1, title: 'Bienvenue au cours', duration: '5:23', isFree: true },
        { id: 2, title: 'Ce que vous allez apprendre', duration: '8:45', isFree: true },
        { id: 3, title: 'Configuration de l&#39;environnement', duration: '15:20', isFree: false },
        { id: 4, title: 'Ressources importantes', duration: '12:14', isFree: false }
      ]
    },
    {
      id: 2,
      title: 'Principes fondamentaux',
      duration: '3h 45m',
      lessons: [
        { id: 5, title: 'Concepts de base', duration: '18:30', isFree: false },
        { id: 6, title: 'Architecture et structure', duration: '22:15', isFree: false },
        { id: 7, title: 'Démonstration pratique', duration: '35:10', isFree: false },
        { id: 8, title: 'Exercices d&#39;application', duration: '28:45', isFree: false },
        { id: 9, title: 'Quiz et révision', duration: '15:20', isFree: false }
      ]
    },
    {
      id: 3,
      title: 'Techniques avancées',
      duration: '5h 20m',
      lessons: [
        { id: 10, title: 'Stratégies optimisées', duration: '25:18', isFree: false },
        { id: 11, title: 'Étude de cas réels', duration: '42:33', isFree: false },
        { id: 12, title: 'Solutions aux problèmes courants', duration: '38:15', isFree: false },
        { id: 13, title: 'Projet pratique guidé', duration: '58:40', isFree: false }
      ]
    }
  ];
  
  useEffect(() => {
    // In a real application, this would be an API call
    const courseData = mockCourses.find(c => c.id === Number(id));
    setCourse(courseData || null);
    setLoading(false);
  }, [id]);
  
  const toggleSection = (sectionId: number) => {
    setOpenSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId) 
        : [...prev, sectionId]
    );
  };
  
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex justify-center">
        <div className="animate-pulse h-6 w-24 bg-gray-200 rounded"></div>
      </div>
    );
  }
  
  if (!course) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Cours non trouvé</h2>
        <p className="mt-2 text-gray-500">Le cours que vous recherchez n&#39;existe pas.</p>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Course header */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-2/3 pr-0 md:pr-8">
                <div className="flex items-center mb-4">
                  <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                    {course.category}
                  </span>
                  <span className="ml-4 text-sm text-gray-500 flex items-center">
                    <BarChart className="h-4 w-4 mr-1" /> {course.level}
                  </span>
                </div>
                
                <h1 className="text-3xl font-bold text-gray-900 mb-4">{course.title}</h1>
                
                <p className="text-gray-600 mb-6">{course.description}</p>
                
                <div className="flex items-center mb-6">
                  <img 
                    src={course.instructor.avatar} 
                    alt={course.instructor.name} 
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{course.instructor.name}</p>
                    <p className="text-sm text-gray-500">{course.instructor.title}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">Durée</p>
                      <p className="font-medium">{course.duration}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Book className="h-5 w-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">Leçons</p>
                      <p className="font-medium">{course.lessons}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">Étudiants</p>
                      <p className="font-medium">{course.students.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Award className="h-5 w-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm text-gray-500">Certificat</p>
                      <p className="font-medium">Inclus</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:w-1/3 mt-6 md:mt-0">
                <div className="bg-gray-50 rounded-lg p-6 shadow-sm">
                  <div className="text-center mb-4">
                    <span className="text-3xl font-bold text-gray-900">{course.price} €</span>
                  </div>
                  
                  <button className="w-full bg-blue-600 text-white py-3 px-4 rounded-md font-medium hover:bg-blue-700 transition-colors mb-3 flex items-center justify-center">
                    <ShoppingCart className="h-5 w-5 mr-2" />
                    Acheter
                  </button>
                  
                  <button className="w-full bg-white text-gray-700 py-3 px-4 rounded-md font-medium border border-gray-300 hover:bg-gray-50 transition-colors flex items-center justify-center">
                    <Heart className="h-5 w-5 mr-2" />
                    Ajouter aux favoris
                  </button>
                  
                  <div className="mt-6">
                    <h3 className="font-medium text-gray-900 mb-3">Ce cours inclut :</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 text-sm">Accès à vie à tous les contenus</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 text-sm">{course.lessons} leçons (vidéos + ressources)</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 text-sm">Exercices pratiques</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 text-sm">Certificat de réussite</span>
                      </li>
                      <li className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600 text-sm">Support instructeur</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Course content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* Course curriculum */}
            <div className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Contenu du cours</h2>
                
                <div className="mb-4">
                  <div className="flex justify-between text-sm text-gray-500 mb-2">
                    <span>{lessonSections.length} sections • {course.lessons} leçons • {course.duration} au total</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {lessonSections.map((section) => (
                    <div key={section.id} className="border border-gray-200 rounded-md overflow-hidden">
                      <button
                        onClick={() => toggleSection(section.id)}
                        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                      >
                        <div className="flex items-center">
                          {openSections.includes(section.id) ? (
                            <ChevronUp className="h-5 w-5 text-gray-500 mr-2" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-500 mr-2" />
                          )}
                          <span className="font-medium text-gray-900">{section.title}</span>
                        </div>
                        <div className="text-sm text-gray-500">
                          {section.lessons.length} leçons • {section.duration}
                        </div>
                      </button>
                      
                      {openSections.includes(section.id) && (
                        <div className="border-t border-gray-200">
                          {section.lessons.map((lesson) => (
                            <div 
                              key={lesson.id} 
                              className="flex items-start p-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0"
                            >
                              <Video className="h-5 w-5 text-gray-400 mr-3 mt-0.5" />
                              <div className="flex-grow">
                                <h3 className="text-gray-900">{lesson.title}</h3>
                                <div className="flex items-center mt-1">
                                  <span className="text-sm text-gray-500">{lesson.duration}</span>
                                  {lesson.isFree && (
                                    <span className="ml-3 text-xs text-blue-600 font-medium px-2 py-0.5 bg-blue-50 rounded">
                                      Aperçu gratuit
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Instructor bio */}
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">À propos de l&#39;instructeur</h2>
                
                <div className="flex items-start mb-6">
                  <img 
                    src={course.instructor.avatar} 
                    alt={course.instructor.name} 
                    className="h-16 w-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{course.instructor.name}</h3>
                    <p className="text-gray-500">{course.instructor.title}</p>
                  </div>
                </div>
                
                <p className="text-gray-600">{course.instructor.bio}</p>
              </div>
            </div>
          </div>
          
          <div>
            {/* Related courses */}
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Vous pourriez aussi aimer</h2>
                
                <div className="space-y-4">
                  {mockCourses
                    .filter(c => c.category === course.category && c.id !== course.id)
                    .slice(0, 3)
                    .map((relatedCourse) => (
                      <a
                        key={relatedCourse.id}
                        href={`/courses/${relatedCourse.id}`}
                        className="block p-4 border border-gray-200 rounded-md hover:border-blue-200 hover:bg-blue-50 transition-colors"
                      >
                        <div className="flex">
                          <img 
                            src={relatedCourse.thumbnail} 
                            alt={relatedCourse.title} 
                            className="h-16 w-24 object-cover rounded mr-3"
                          />
                          <div>
                            <h3 className="text-sm font-medium text-gray-900 line-clamp-2 mb-1">
                              {relatedCourse.title}
                            </h3>
                            <div className="flex items-center text-xs text-gray-500">
                              <Clock className="h-3 w-3 mr-1" />
                              <span>{relatedCourse.duration}</span>
                              <span className="mx-2">•</span>
                              <span>{relatedCourse.level}</span>
                            </div>
                            <p className="text-sm font-medium text-blue-600 mt-1">
                              {relatedCourse.price} €
                            </p>
                          </div>
                        </div>
                      </a>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;