import React from 'react';
import Hero from '../components/Hero';
import FeaturedCourses from '../components/FeaturedCourses';
import Benefits from '../components/Benefits';
import Testimonials from '../components/Testimonials';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div>
      <Hero />
      <FeaturedCourses />
      <Benefits />
      
      {/* Categories Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Explorez nos catégories</h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
              Trouvez la formation parfaite pour développer vos compétences parmi nos diverses catégories.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {['Développement Web', 'Marketing Digital', 'Design UX/UI', 'Business', 'Data Science', 'Développement Personnel', 'Photographie', 'Finance'].map((category, index) => (
              <Link 
                key={index} 
                to={`/categories/${category.toLowerCase().replace(/\s+/g, '-')}`}
                className="bg-gray-50 hover:bg-blue-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-all text-center group"
              >
                <h3 className="text-lg font-medium text-gray-900 group-hover:text-blue-600 transition-colors">
                  {category}
                </h3>
                <div className="mt-2 flex justify-center">
                  <ArrowRight className="h-5 w-5 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      <Testimonials />
      
      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à développer vos compétences ?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Rejoignez des milliers d'apprenants qui ont transformé leur carrière grâce à nos formations de qualité.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link 
              to="/signup" 
              className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-600 bg-white hover:bg-blue-50 transition-colors"
            >
              S'inscrire gratuitement
            </Link>
            <Link 
              to="/courses" 
              className="inline-flex items-center justify-center px-8 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-blue-700 transition-colors"
            >
              Explorer les cours
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;