import React, { useState, useEffect } from 'react';
import { Search, Filter, ChevronDown } from 'lucide-react';
import CourseCard from '../components/CourseCard';
import { Course } from '../types/course';
import { mockCourses } from '../data/mockData';

const CourseCatalog: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<Course[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [isPriceOpen, setIsPriceOpen] = useState(false);
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(200);
  
  const categories = [...new Set(mockCourses.map(course => course.category))];
  const levels = [...new Set(mockCourses.map(course => course.level))];
  
  useEffect(() => {
    // In a real application, this would be an API call
    setCourses(mockCourses);
    setFilteredCourses(mockCourses);
  }, []);
  
  useEffect(() => {
    let results = courses;
    
    // Apply search filter
    if (searchTerm) {
      results = results.filter(course => 
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply category filter
    if (selectedCategory) {
      results = results.filter(course => course.category === selectedCategory);
    }
    
    // Apply level filter
    if (selectedLevel) {
      results = results.filter(course => course.level === selectedLevel);
    }
    
    // Apply price filter
    results = results.filter(course => 
      course.price >= minPrice && course.price <= maxPrice
    );
    
    setFilteredCourses(results);
  }, [searchTerm, selectedCategory, selectedLevel, minPrice, maxPrice, courses]);
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900">Catalogue de cours</h1>
        <p className="mt-4 text-xl text-gray-500">
          Parcourez notre sélection de formations de qualité pour développer vos compétences.
        </p>
      </div>
      
      <div className="flex flex-col md:flex-row gap-8 mb-8">
        {/* Filters sidebar for larger screens */}
        <div className="md:w-1/4 bg-white rounded-lg shadow-md p-6 h-fit sticky top-24">
          <div className="mb-6">
            <h2 className="font-medium text-lg text-gray-900 mb-4">Filtres</h2>
            <div className="relative">
              <input
                type="text"
                placeholder="Rechercher des cours..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="font-medium text-gray-700 mb-3">Catégorie</h3>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Toutes les catégories</option>
              {categories.map((category, index) => (
                <option key={index} value={category}>{category}</option>
              ))}
            </select>
          </div>
          
          <div className="mb-6">
            <h3 className="font-medium text-gray-700 mb-3">Niveau</h3>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full border border-gray-300 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Tous les niveaux</option>
              {levels.map((level, index) => (
                <option key={index} value={level}>{level}</option>
              ))}
            </select>
          </div>
          
          <div>
            <button
              onClick={() => setIsPriceOpen(!isPriceOpen)}
              className="flex items-center justify-between w-full text-left font-medium text-gray-700 mb-3"
            >
              <span>Prix</span>
              <ChevronDown 
                className={`h-5 w-5 text-gray-500 transform transition-transform ${isPriceOpen ? 'rotate-180' : ''}`} 
              />
            </button>
            
            {isPriceOpen && (
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-500 mb-2">
                  <span>{minPrice} €</span>
                  <span>{maxPrice} €</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={minPrice}
                  onChange={(e) => setMinPrice(Number(e.target.value))}
                  className="w-full mb-4"
                />
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            )}
          </div>
          
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('');
              setSelectedLevel('');
              setMinPrice(0);
              setMaxPrice(200);
            }}
            className="w-full py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 mt-4"
          >
            Réinitialiser les filtres
          </button>
        </div>
        
        {/* Course grid */}
        <div className="md:w-3/4">
          {/* Mobile search and filter */}
          <div className="mb-6 md:hidden">
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Rechercher des cours..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full border border-gray-300 rounded-md py-2 pl-10 pr-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400 h-5 w-5" />
            </div>
            <button
              className="w-full flex items-center justify-center py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Filter className="h-5 w-5 mr-2" />
              Filtres
            </button>
          </div>
          
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">Aucun cours ne correspond à vos critères de recherche.</p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('');
                  setSelectedLevel('');
                  setMinPrice(0);
                  setMaxPrice(200);
                }}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Réinitialiser les filtres
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CourseCatalog;