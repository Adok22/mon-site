import React from 'react';
import { Clock, Users, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Course } from '../types/course';

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  return (
    <Link 
      to={`/courses/${course.id}`}
      className="block bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
    >
      <div className="relative">
        <img 
          src={course.thumbnail} 
          alt={course.title} 
          className="w-full h-48 object-cover"
        />
        {course.featured && (
          <div className="absolute top-2 right-2 bg-yellow-500 text-white text-xs font-bold px-2 py-1 rounded">
            Populaire
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-center mb-2">
          <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
            {course.category}
          </span>
          <div className="flex items-center ml-auto">
            <Star className="h-4 w-4 text-yellow-500" />
            <span className="text-sm ml-1 text-gray-700">{course.rating}</span>
          </div>
        </div>
        
        <h3 className="text-lg font-bold text-gray-900 mb-2">{course.title}</h3>
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{course.description}</p>
        
        <div className="flex items-center text-sm text-gray-500 mt-auto">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center ml-4">
            <Users className="h-4 w-4 mr-1" />
            <span>{course.students} étudiants</span>
          </div>
        </div>
      </div>
      
      <div className="px-4 py-3 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src={course.instructor.avatar} 
            alt={course.instructor.name}
            className="h-8 w-8 rounded-full object-cover"
          />
          <span className="ml-2 text-sm font-medium text-gray-700">{course.instructor.name}</span>
        </div>
        <div className="text-blue-600 font-bold">
          {course.price === 0 ? 'Gratuit' : `${course.price} €`}
        </div>
      </div>
    </Link>
  );
};

export default CourseCard;