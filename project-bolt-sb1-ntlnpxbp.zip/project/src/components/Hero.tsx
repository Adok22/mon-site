import React from 'react';
import { Search, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <svg
            className="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-white transform translate-x-1/2"
            fill="currentColor"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <polygon points="50,0 100,0 50,100 0,100" />
          </svg>

          <div className="relative pt-6 px-4 sm:px-6 lg:px-8"></div>

          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
                <span className="block">Votre expertise,</span>
                <span className="block text-blue-600">votre plateforme de formation en ligne.</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                Virus Mentale est votre partenaire stratégique pour créer, vendre et gérer vos formations en ligne. Notre plateforme simple à utiliser facilite l'apprentissage pour vos étudiants.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <Link
                    to="/signup"
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10 transition-colors"
                  >
                    Démarrer
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Link
                    to="/courses"
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 md:py-4 md:text-lg md:px-10 transition-colors"
                  >
                    Explorer les cours
                  </Link>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
        <div className="h-56 w-full bg-blue-600 sm:h-72 md:h-96 lg:w-full lg:h-full relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-blue-600 opacity-90"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.2)_0%,rgba(255,255,255,0)_60%)]"></div>
          
          <div className="absolute left-1/4 top-1/4 bg-white rounded-lg shadow-xl p-4 transform -rotate-6 w-64">
            <div className="h-4 w-1/2 bg-gray-200 rounded mb-3"></div>
            <div className="h-8 w-full bg-blue-100 rounded mb-3"></div>
            <div className="h-32 w-full bg-gray-100 rounded"></div>
          </div>
          
          <div className="absolute right-1/4 bottom-1/4 bg-white rounded-lg shadow-xl p-4 transform rotate-6 w-64">
            <div className="flex items-center mb-3">
              <div className="h-8 w-8 bg-blue-100 rounded-full"></div>
              <div className="ml-2">
                <div className="h-3 w-24 bg-gray-200 rounded"></div>
                <div className="h-2 w-16 bg-gray-100 rounded mt-1"></div>
              </div>
            </div>
            <div className="h-24 w-full bg-gray-100 rounded mb-3"></div>
            <div className="flex justify-between">
              <div className="h-6 w-16 bg-blue-100 rounded"></div>
              <div className="h-6 w-12 bg-yellow-100 rounded"></div>
            </div>
          </div>
          
          <div className="absolute bottom-8 left-1/4 transform -translate-x-1/2 bg-white/90 backdrop-blur rounded-full h-12 w-12 flex items-center justify-center shadow-lg">
            <div className="h-6 w-6 bg-blue-500 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;