import React from 'react';
import { Brain } from 'lucide-react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "h-8 w-auto" }) => {
  return (
    <div className={`relative ${className}`}>
      <div className="absolute inset-0 bg-blue-100 rounded-full opacity-50 animate-pulse"></div>
      <div className="relative flex items-center justify-center">
        <Brain className="text-blue-600" size={28} />
        <div className="absolute w-3 h-3 rounded-full bg-blue-600 top-0 right-0 animate-ping opacity-75"></div>
      </div>
    </div>
  );
};

export default Logo;