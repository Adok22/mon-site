import React from 'react';
import { CheckCircle, Award, BookOpen, Clock } from 'lucide-react';

const Benefits: React.FC = () => {
  const benefits = [
    {
      icon: <BookOpen className="h-8 w-8 text-blue-600" />,
      title: 'Contenu de qualité',
      description: 'Accédez à des formations créées par des experts reconnus dans leur domaine.'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Apprentissage à votre rythme',
      description: 'Apprenez quand vous voulez, où vous voulez, et avancez à votre propre rythme.'
    },
    {
      icon: <Award className="h-8 w-8 text-blue-600" />,
      title: 'Certificats reconnus',
      description: 'Obtenez des certificats pour valoriser vos nouvelles compétences sur le marché.'
    },
    {
      icon: <CheckCircle className="h-8 w-8 text-blue-600" />,
      title: 'Support personnalisé',
      description: 'Bénéficiez d&#39;un accompagnement de qualité tout au long de votre parcours.'
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Pourquoi choisir Virus Mentale ?
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Notre plateforme offre un environnement d'apprentissage optimal pour développer vos compétences.
          </p>
        </div>

        <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex flex-col items-center text-center">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-blue-100 mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-500">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;