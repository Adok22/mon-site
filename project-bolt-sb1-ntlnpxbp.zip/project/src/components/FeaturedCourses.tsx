import React, { useState, useEffect } from 'react';
import CourseCard from './CourseCard';
import { Course } from '../types/course';
import { mockCourses } from '../data/mockData';

const FeaturedCourses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  
  useEffect(() => {
    // In a real application, this would be an API call
    setCourses(mockCourses.filter(course => course.featured));
  }, []);

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Formations à la une</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Découvrez nos formations les plus populaires et développez vos compétences dès aujourd'hui.
          </p>
        </div>
        
        <div className="grid grid-cols-1 mt-12 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a 
            href="/courses" 
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 transition-colors"
          >
            Voir tous les cours
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturedCourses;